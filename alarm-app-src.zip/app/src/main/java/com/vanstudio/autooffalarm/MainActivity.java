package com.vanstudio.autooffalarm;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(9, 13, 25);
    private static final int SURFACE = Color.rgb(23, 30, 52);
    private static final int WHITE = Color.rgb(241, 244, 255);
    private static final int MUTED = Color.rgb(153, 166, 198);
    private static final int ACCENT = Color.rgb(149, 167, 255);
    private static final int[] SECONDS = {15, 30, 60, 120, 180, 300, 600, 900, 1800};
    private static final String[] DURATIONS = {"15 секунд", "30 секунд", "1 минута", "2 минуты",
        "3 минуты", "5 минут", "10 минут", "15 минут", "30 минут"};

    private int hour;
    private int minute;
    private TextView clock;
    private TextView status;
    private TextView summary;
    private Spinner durationSpinner;
    private Button cancelButton;
    private Button saveButton;

    private int dp(float value) { return Math.round(getResources().getDisplayMetrics().density * value); }

    private GradientDrawable background(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable outlined(int color, float radius, int stroke) {
        GradientDrawable d = background(color, radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void verticalSpace(LinearLayout parent, int height) {
        View blank = new View(this);
        parent.addView(blank, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private LinearLayout panel(LinearLayout parent) {
        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        result.setPadding(dp(22), dp(22), dp(22), dp(22));
        result.setBackground(outlined(SURFACE, 24, Color.rgb(40, 50, 75)));
        parent.addView(result, new LinearLayout.LayoutParams(-1, -2));
        return result;
    }

    private Button button(String label, int bg, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(background(bg, 15));
        b.setMinHeight(dp(56));
        return b;
    }

    private void withMargin(LinearLayout parent, View view, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        parent.addView(view, lp);
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        Calendar now = Calendar.getInstance();
        hour = now.get(Calendar.HOUR_OF_DAY);
        minute = now.get(Calendar.MINUTE);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 77);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(42), dp(22), dp(32));
        scroll.addView(root);
        setContentView(scroll);

        TextView eyebrow = text("AUTO OFF  /  ALARM", 12, ACCENT, true);
        eyebrow.setLetterSpacing(0.16f);
        root.addView(eyebrow);
        TextView title = text("Будильник, который\nзамолчит сам.", 31, WHITE, true);
        title.setLineSpacing(dp(2), 1.0f);
        withMargin(root, title, 10);
        TextView subtitle = text("Выберите время и сколько будет звучать сигнал. После этого он отключится автоматически.",
            15, MUTED, false);
        subtitle.setLineSpacing(dp(2), 1.1f);
        withMargin(root, subtitle, 12);
        verticalSpace(root, 30);

        LinearLayout card = panel(root);
        TextView atLabel = text("ВРЕМЯ ЗВОНКА", 12, MUTED, true);
        atLabel.setLetterSpacing(0.1f);
        card.addView(atLabel);
        clock = text("", 55, WHITE, true);
        clock.setGravity(Gravity.CENTER);
        withMargin(card, clock, 7);
        clock.setPadding(0, dp(9), 0, dp(9));
        clock.setBackground(background(Color.rgb(30, 39, 65), 15));
        updateClock();
        Button pickTime = button("Выбрать время", Color.rgb(54, 67, 105), WHITE);
        withMargin(card, pickTime, 14);
        pickTime.setOnClickListener(view -> {
            TimePickerDialog dialog = new TimePickerDialog(this, (picker, h, m) -> {
                hour = h;
                minute = m;
                updateClock();
            }, hour, minute, true);
            dialog.show();
        });

        verticalSpace(root, 16);
        LinearLayout durationCard = panel(root);
        TextView durLabel = text("АВТООТКЛЮЧЕНИЕ ЧЕРЕЗ", 12, MUTED, true);
        durLabel.setLetterSpacing(0.1f);
        durationCard.addView(durLabel);
        durationSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
            android.R.layout.simple_spinner_item, DURATIONS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        durationSpinner.setAdapter(adapter);
        durationSpinner.setSelection(2);
        durationSpinner.setMinimumHeight(dp(54));
        withMargin(durationCard, durationSpinner, 7);
        TextView durationNote = text("Сигнал не будет звучать бесконечно.", 13, MUTED, false);
        withMargin(durationCard, durationNote, 7);

        saveButton = button("Установить будильник", ACCENT, Color.rgb(12, 16, 30));
        withMargin(root, saveButton, 24);
        saveButton.setOnClickListener(view -> setAlarm());
        cancelButton = button("Отменить будильник", Color.rgb(44, 51, 76), WHITE);
        withMargin(root, cancelButton, 10);
        cancelButton.setOnClickListener(view -> {
            AlarmStore.cancel(this);
            refreshState();
            Toast.makeText(this, "Будильник отменён", Toast.LENGTH_SHORT).show();
        });

        verticalSpace(root, 26);
        LinearLayout stateCard = panel(root);
        TextView statusLabel = text("СТАТУС", 12, MUTED, true);
        statusLabel.setLetterSpacing(0.1f);
        stateCard.addView(statusLabel);
        status = text("", 20, WHITE, true);
        withMargin(stateCard, status, 10);
        summary = text("", 14, MUTED, false);
        withMargin(stateCard, summary, 7);

        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (!nm.canUseFullScreenIntent()) {
                TextView hint = text("Для показа звонка поверх экрана разрешите полноэкранные уведомления.",
                    13, MUTED, false);
                withMargin(root, hint, 22);
                Button permission = button("Разрешить полноэкранный звонок", Color.rgb(44, 51, 76), WHITE);
                withMargin(root, permission, 12);
                permission.setOnClickListener(view -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    try { startActivity(intent); }
                    catch (Exception ignored) { Toast.makeText(this, "Откройте разрешения уведомлений в настройках", Toast.LENGTH_LONG).show(); }
                });
            }
        }
        refreshState();
    }

    private void updateClock() { clock.setText(String.format(Locale.ROOT, "%02d:%02d", hour, minute)); }

    private void setAlarm() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_MONTH, 1);
        try {
            AlarmStore.schedule(this, cal.getTimeInMillis(), SECONDS[durationSpinner.getSelectedItemPosition()]);
            refreshState();
            Toast.makeText(this, "Будильник установлен", Toast.LENGTH_SHORT).show();
        } catch (SecurityException ex) {
            Toast.makeText(this, "Нужно разрешение на точные будильники", Toast.LENGTH_LONG).show();
            if (Build.VERSION.SDK_INT >= 31) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()))); }
                catch (Exception ignored) { }
            }
        }
    }

    private void refreshState() {
        boolean enabled = AlarmStore.prefs(this).getBoolean(AlarmStore.ENABLED, false);
        long when = AlarmStore.prefs(this).getLong(AlarmStore.TRIGGER_AT, 0);
        if (enabled && when <= System.currentTimeMillis()) {
            AlarmStore.cancel(this);
            enabled = false;
        }
        status.setText(enabled ? "● Будильник активен" : "○ Нет активного будильника");
        status.setTextColor(enabled ? Color.rgb(153, 231, 191) : WHITE);
        if (enabled) {
            DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT,
                new Locale("ru", "RU"));
            int seconds = AlarmStore.prefs(this).getInt(AlarmStore.DURATION, 60);
            summary.setText("Сработает " + df.format(new Date(when)) + "\nОтключится через "
                + (seconds < 60 ? seconds + " сек." : seconds / 60 + " мин.") + " после начала звонка.");
        } else {
            summary.setText("Выберите время и длительность, затем нажмите «Установить».");
        }
        cancelButton.setVisibility(enabled ? View.VISIBLE : View.GONE);
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) refreshState();
    }
}
