package com.vanstudio.autooffalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public final class AlarmStore {
    public static final String PREFS = "alarm_state";
    public static final String ENABLED = "enabled";
    public static final String TRIGGER_AT = "trigger_at";
    public static final String DURATION = "duration_seconds";
    public static final String RING_END_AT = "ring_end_at";
    private static final int START_REQUEST = 1001;
    private static final int STOP_REQUEST = 1002;

    private AlarmStore() { }

    public static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static PendingIntent startPendingIntent(Context context) {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction("com.vanstudio.autooffalarm.FIRE");
        return PendingIntent.getBroadcast(context, START_REQUEST, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent stopPendingIntent(Context context) {
        Intent intent = new Intent(context, StopReceiver.class).setAction("com.vanstudio.autooffalarm.STOP");
        return PendingIntent.getBroadcast(context, STOP_REQUEST, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context context, long when, int durationSeconds) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        cancel(context);
        prefs(context).edit().putBoolean(ENABLED, true).putLong(TRIGGER_AT, when)
            .putInt(DURATION, durationSeconds).apply();
        PendingIntent open = PendingIntent.getActivity(context, 1003,
            new Intent(context, MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        manager.setAlarmClock(new AlarmManager.AlarmClockInfo(when, open), startPendingIntent(context));
    }

    public static void cancel(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(startPendingIntent(context));
        prefs(context).edit().putBoolean(ENABLED, false).apply();
    }

    static void scheduleStop(Context context, long when) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when,
            stopPendingIntent(context));
    }

    static void cancelStop(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(stopPendingIntent(context));
    }
}
