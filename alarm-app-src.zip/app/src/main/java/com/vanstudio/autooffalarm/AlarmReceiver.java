package com.vanstudio.autooffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!AlarmStore.prefs(context).getBoolean(AlarmStore.ENABLED, false)) return;
        AlarmStore.prefs(context).edit().putBoolean(AlarmStore.ENABLED, false).apply();
        Intent service = new Intent(context, AlarmService.class).setAction(AlarmService.ACTION_START);
        context.startForegroundService(service);
    }
}
