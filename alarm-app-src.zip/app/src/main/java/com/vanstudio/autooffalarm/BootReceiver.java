package com.vanstudio.autooffalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = AlarmStore.prefs(context);
        if (!p.getBoolean(AlarmStore.ENABLED, false)) return;
        long when = p.getLong(AlarmStore.TRIGGER_AT, 0);
        if (when <= System.currentTimeMillis()) {
            AlarmStore.cancel(context);
            return;
        }
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent open = PendingIntent.getActivity(context, 1003,
            new Intent(context, MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        manager.setAlarmClock(new AlarmManager.AlarmClockInfo(when, open), AlarmStore.startPendingIntent(context));
    }
}
