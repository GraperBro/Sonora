package com.vanstudio.autooffalarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.io.IOException;

public class AlarmService extends Service {
    public static final String ACTION_START = "com.vanstudio.autooffalarm.ACTION_START";
    public static final String ACTION_STOP = "com.vanstudio.autooffalarm.ACTION_STOP";
    private static final String CHANNEL = "ringing_alarm_v1";
    private static final int NOTIFICATION = 108;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private Runnable stopRunnable;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopRing();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (player != null) return START_NOT_STICKY;
        int seconds = AlarmStore.prefs(this).getInt(AlarmStore.DURATION, 60);
        long endAt = System.currentTimeMillis() + (long) seconds * 1000L;
        AlarmStore.prefs(this).edit().putLong(AlarmStore.RING_END_AT, endAt).apply();
        createChannel();
        startForeground(NOTIFICATION, buildNotification());
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AutoOffAlarm:Ringing");
        wakeLock.acquire((long) seconds * 1000L + 10000L);
        startSound();
        AlarmStore.scheduleStop(this, endAt);
        stopRunnable = () -> {
            stopRing();
            stopSelf();
        };
        handler.postDelayed(stopRunnable, (long) seconds * 1000L);
        return START_NOT_STICKY;
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Звонок будильника",
            NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Активный будильник с автоматическим выключением");
        channel.setSound(null, null);
        channel.enableVibration(true);
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent show = new Intent(this, RingActivity.class);
        show.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullScreen = PendingIntent.getActivity(this, 2001, show,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, StopReceiver.class).setAction("com.vanstudio.autooffalarm.STOP");
        PendingIntent dismiss = PendingIntent.getBroadcast(this, 2002, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle("Пора просыпаться")
            .setContentText("Будильник выключится автоматически")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(fullScreen)
            .setFullScreenIntent(fullScreen, true)
            .addAction(new Notification.Action.Builder(null, "Выключить", dismiss).build())
            .build();
    }

    private void startSound() {
        Uri uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
        if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (uri == null) return;
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception ex) {
            if (player != null) { player.release(); player = null; }
        }
    }

    private void stopRing() {
        if (stopRunnable != null) { handler.removeCallbacks(stopRunnable); stopRunnable = null; }
        AlarmStore.cancelStop(this);
        if (player != null) {
            try { player.stop(); } catch (IllegalStateException ignored) { }
            player.release();
            player = null;
        }
        if (wakeLock != null) {
            if (wakeLock.isHeld()) wakeLock.release();
            wakeLock = null;
        }
        AlarmStore.prefs(this).edit().putLong(AlarmStore.RING_END_AT, 0).apply();
        stopForeground(STOP_FOREGROUND_REMOVE);
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.cancel(NOTIFICATION);
    }

    @Override public void onDestroy() {
        stopRing();
        super.onDestroy();
    }
}
