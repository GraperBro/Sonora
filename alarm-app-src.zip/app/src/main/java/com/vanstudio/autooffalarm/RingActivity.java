package com.vanstudio.autooffalarm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RingActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView left;
    private final Runnable update = new Runnable() {
        @Override public void run() {
            long end = AlarmStore.prefs(RingActivity.this).getLong(AlarmStore.RING_END_AT, 0);
            long remain = Math.max(0, (end - System.currentTimeMillis() + 999) / 1000);
            if (end == 0 || remain == 0) {
                finish();
                return;
            }
            left.setText("Автоотключение через " + (remain / 60) + ":"
                + String.format(java.util.Locale.ROOT, "%02d", remain % 60));
            handler.postDelayed(this, 1000);
        }
    };

    private int dp(int dp) { return Math.round(dp * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(9, 13, 25));
        getWindow().setNavigationBarColor(Color.rgb(9, 13, 25));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(25), dp(32), dp(25), dp(32));
        root.setBackgroundColor(Color.rgb(9, 13, 25));

        TextView icon = new TextView(this);
        icon.setText("◉");
        icon.setTextColor(Color.rgb(149, 167, 255));
        icon.setTextSize(90);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon);

        TextView heading = new TextView(this);
        heading.setText("Пора просыпаться");
        heading.setTextSize(30);
        heading.setTextColor(Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);

        left = new TextView(this);
        left.setTextSize(17);
        left.setTextColor(Color.rgb(173, 184, 218));
        left.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, -2);
        labelParams.topMargin = dp(16);
        root.addView(left, labelParams);

        Button stop = new Button(this);
        stop.setText("Выключить сейчас");
        stop.setAllCaps(false);
        stop.setTextColor(Color.rgb(13, 17, 30));
        stop.setTextSize(17);
        stop.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(Color.rgb(149, 167, 255));
        shape.setCornerRadius(dp(18));
        stop.setBackground(shape);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(60));
        buttonParams.topMargin = dp(50);
        root.addView(stop, buttonParams);
        stop.setOnClickListener(view -> {
            startService(new Intent(this, AlarmService.class).setAction(AlarmService.ACTION_STOP));
            finish();
        });
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(update);
        handler.post(update);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(update);
        super.onPause();
    }
}
