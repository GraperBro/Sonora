package com.vanstudio.autooffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class StopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        context.startService(new Intent(context, AlarmService.class).setAction(AlarmService.ACTION_STOP));
    }
}
